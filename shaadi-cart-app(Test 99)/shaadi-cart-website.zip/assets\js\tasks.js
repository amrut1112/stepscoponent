// tasks.js

document.addEventListener('DOMContentLoaded', async () => {
    // Check authentication
    const isLoggedIn = await window.supabaseClient.isAuthenticated();
    if (!isLoggedIn) {
        window.location.href = 'login.html'; // Redirect to login if not authenticated
        return;
    }

    const currentGroupId = localStorage.getItem('currentGroupId');
    const taskList = document.getElementById('task-list');
    const newTaskInput = document.getElementById('new-task-input');
    const addTaskBtn = document.getElementById('add-task-btn');

    if (!currentGroupId) {
        taskList.innerHTML = '<p>Please select a wedding group first.</p>';
        return;
    }

    // Function to fetch tasks
    async function fetchTasks() {
        const { data, error } = await supabase
            .from('tasks')
            .select('*')
            .eq('group_id', currentGroupId)
            .order('created_at', { ascending: true });

        if (error) {
            console.error('Error fetching tasks:', error);
            taskList.innerHTML = '<p>Error loading tasks.</p>';
            return [];
        }
        return data;
    }

    // Function to render tasks
    function renderTasks(tasks) {
        taskList.innerHTML = ''; // Clear current list
        if (tasks.length === 0) {
            taskList.innerHTML = '<p>No tasks yet!</p>';
            return;
        }
        tasks.forEach(task => {
            const taskElement = document.createElement('div');
            taskElement.classList.add('task-item');
            taskElement.dataset.taskId = task.id; // Store task ID
            
            // Add checkbox for completion
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = task.is_completed;
            checkbox.addEventListener('change', () => toggleTaskCompletion(task.id, checkbox.checked));

            // Add span for description (editable)
            const descriptionSpan = document.createElement('span');
            descriptionSpan.textContent = task.description;
            descriptionSpan.classList.add('task-description');
            descriptionSpan.style.textDecoration = task.is_completed ? 'line-through' : 'none';
            descriptionSpan.addEventListener('dblclick', () => enableTaskEditing(taskElement, task.id, descriptionSpan));

            // Add delete button
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete'; // Or use an icon
            deleteButton.classList.add('delete-task-btn');
            deleteButton.addEventListener('click', () => deleteTask(task.id));

            taskElement.appendChild(checkbox);
            taskElement.appendChild(descriptionSpan);
            taskElement.appendChild(deleteButton);

            taskList.appendChild(taskElement);
        });
    }

    // Function to toggle task completion
    async function toggleTaskCompletion(taskId, isCompleted) {
        const { error } = await supabase
            .from('tasks')
            .update({ is_completed: isCompleted })
            .eq('id', taskId);

        if (error) {
            console.error('Error updating task completion:', error);
            alert('Failed to update task status.');
        } else {
             loadAndRenderTasks(); // Refresh list to show updated status/styling
        }
    }

    // Function to delete a task
    async function deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            const { error } = await supabase
                .from('tasks')
                .delete()
                .eq('id', taskId);

            if (error) {
                console.error('Error deleting task:', error);
                alert('Failed to delete task.');
            } else {
                loadAndRenderTasks(); // Refresh list
            }
        }
    }

    // Function to enable task editing
    function enableTaskEditing(taskElement, taskId, descriptionSpan) {
        const currentText = descriptionSpan.textContent;
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentText;
        input.classList.add('edit-task-input');
        
        // Replace span with input
        taskElement.replaceChild(input, descriptionSpan);

        input.focus();

        // Save on Enter or blur
        const saveEdit = async () => {
            const newDescription = input.value.trim();
            if (newDescription === currentText || !newDescription) {
                // No change or empty, revert
                taskElement.replaceChild(descriptionSpan, input);
                return;
            }

            const { error } = await supabase
                .from('tasks')
                .update({ description: newDescription })
                .eq('id', taskId);

            if (error) {
                console.error('Error updating task:', error);
                alert('Failed to update task.');
                 taskElement.replaceChild(descriptionSpan, input); // Revert on error
            } else {
                descriptionSpan.textContent = newDescription; // Update span text
                taskElement.replaceChild(descriptionSpan, input); // Replace input with updated span
            }
        };

        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                saveEdit();
            }
        });
        input.addEventListener('blur', saveEdit);
    }

    // Function to add a new task
    async function addTask() {
        const description = newTaskInput.value.trim();
        if (!description) return; // Don't add empty tasks

        // You might want to link the task to the current user if you added a user_id column to the tasks table
        const user = await window.supabaseClient.getCurrentUser();
        const userId = user ? user.id : null;

        const { data, error } = await supabase
            .from('tasks')
            .insert([{ 
                group_id: currentGroupId, 
                description: description,
                created_by: userId // Link task to creator if user_id column exists
            }]);

        if (error) {
            console.error('Error adding task:', error);
            alert('Failed to add task.');
        } else {
            newTaskInput.value = ''; // Clear input
            loadAndRenderTasks(); // Refresh the list
        }
    }

    // Load and render tasks on page load
    async function loadAndRenderTasks() {
        // Add a loading indicator if needed
        const tasks = await fetchTasks();
        renderTasks(tasks);
    }

    // Event listener for add button
    addTaskBtn.addEventListener('click', addTask);

    // Allow adding task on Enter key press in the input field
    newTaskInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // Prevent form submission (if applicable)
            addTask();
        }
    });

    // Initial load
    loadAndRenderTasks();
}); 